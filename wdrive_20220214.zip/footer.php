<div id="msgDisplayDiv"></div>
</div>
<!-- End of mainContentDiv -->
<div id="footer-main-fcoder" class="navbar navbar-default">
  <div id="developedbyCredit">Developed by ICT CELL, BB Barishal and Powered by ICTIMMD, Head Office. All Rights Reserved.</div>
  <div id="operationActionStatus" class="general-scroll-bar-style"></div>
</div>
<!-- End of Base -->
</body>
<script>  
</script>
</html>