 <?php phpinfo(); ?>
